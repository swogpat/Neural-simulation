% Thanks for using the THANS, an artificial neural system that is
% biological plausible and directly based on biophysics.

% This project is supported by Tsinghua University, China. The Copyright
% belongs to Mr. Yang Tian at tianyang16@mails.tsinghua.edu.cn and Mr.
% Weihua He at hwh16@mails.tsinghua.edu.cn. If you have any question about
% the code, please connect with them via e-mail.

% Note that this code is the vision without GUI, if you want to use GUI,
% please see another vision whose name ends with GUI.

% In short, you need to finish two steps to start your own experiment.
% The first step is to set the initial settings for the system. The second
% step is to set the experiment type.

%% Setting Part for the Whole System
%% Initial Settings
% In this part, we define some basic information for our computtational
% model. The [Width,Length,Hight] will define the whole space, and the norm
% is 1 micrometer. The IterationTime=0.01 means that each iteration
% corresponds to 0.01 s or 10 ms. Apart of that, the norm of all
% concentration is umol/um^3.

Width=500;
Length=500;
Hight=500;
InitialIterationTimes=100;       % This is the iteration number of the initalization part.
MinRadius=20;
MaxRadius=30;
NumofInitialSomas=15;
NumofInitialCa=5;
MinCCaOutSide=(1/NumofInitialCa)*Width*Length*Hight*1000*10^(-15);
MaxCCaOutSide=(1/NumofInitialCa)*Width*Length*Hight*2000*10^(-15);
MinCCaOutSideFast=1000*10^(-15);
MaxCCaOutSideFast=2000*10^(-15);
MinCCaInSide=0.1*10^(-15);
MaxCCaInSide=1*10^(-15);
IterationTime=0.001;
DiffusionCCa=0.01;
InfluxPermeabilityConstant=0.0001;      % This is the passive membrane of permeability.
ExperimentTimes=100;        % This is the iteration number of the experiment part.

%% Define the Structure of Settings
% In this part, we define some structure to pass the information.
BasicSettings.Width=Width;
BasicSettings.Length=Length;
BasicSettings.Hight=Hight;
BasicSettings.IterationTime=IterationTime;
BasicSettings.InitialIterationTimes=InitialIterationTimes;

SituationCCaOutSide.NumofInitialCa=NumofInitialCa;
SituationCCaOutSide.MinCCaOutSide=MinCCaOutSide;
SituationCCaOutSide.MaxCCaOutSide=MaxCCaOutSide;
SituationCCaOutSide.MinCCaOutSideFast=MinCCaOutSideFast;
SituationCCaOutSide.MaxCCaOutSideFast=MaxCCaOutSideFast;

SituationSomas.NumofInitialSomas=NumofInitialSomas;
SituationSomas.MinRadius=MinRadius;
SituationSomas.MaxRadius=MaxRadius;

SituationCCaDiffusion.DiffusionCCa=DiffusionCCa;
SituationCCaDiffusion.MinCCaInSide=MinCCaInSide;
SituationCCaDiffusion.MaxCCaInSide=MaxCCaInSide;

SituationCaInflux.InfluxPermeabilityConstant=InfluxPermeabilityConstant;

%% Experiment Type
% There are two types of experiments. The first type is the complete one
% that starts from the initialization of Ca distributaion based on the
% diffuision process. The second type is the fast one, which starts from
% the initialization of Ca distribution based on the random distribution.
% If you want to test the whole system, we encourage you to use the first
% type and please note that the InitialIterationTimes should be set large
% enough (for instance 5000 for a 500*500*500 space). But if you only care
% about the neural development and just want to do some neural experiment,
% we encourage you to use the second type so that you don't need to wait
% for a really long time to initialize the Ca distribution. 

% If you want to run the first type, do not set the space to be too large,
% or the MATLAB might breakdown if you don't have enough computing power!

InitializationType=2;                                           % Type 1 for the first type and type 2 for the second type

%% Experiment Part
% This is the experiment part, you will need to wait for a while to let the
% system finish running. 
%% Initialization Experiment
if InitializationType==1
    %% Define the Initialization Distribution of Somas
    disp('Define the Initialization Distribution of Somas');
    [CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas]=InitializationofSomaDistribution(BasicSettings,SituationSomas);
    InformationInitializedofSomas.CellofInitialCentroidofSomas=CellofInitialCentroidofSomas;
    InformationInitializedofSomas.VectorofInitialRadiusofSomas=VectorofInitialRadiusofSomas;
    %% Plot the Initializetion Distribution of Somas
    disp('Plot the Initializetion Distribution of Somas');
    [XLocationofCentroid,YLocationofCentroid,ZLocationofCentroid,VectorofInitialColorofSomas,FigureofInitialSoma]=PlotFunctionofSomas(InformationInitializedofSomas,SituationSomas);
    InitializetionPlotInformationofSoma.XLocationofCentroid=XLocationofCentroid;
    InitializetionPlotInformationofSoma.YLocationofCentroid=YLocationofCentroid;
    InitializetionPlotInformationofSoma.ZLocationofCentroid=ZLocationofCentroid;
    InitializetionPlotInformationofSoma.VectorofInitialColorofSomas=VectorofInitialColorofSomas;
    %% Define the Initialization Distribution of Ca
    disp('Define the Initialization Distribution of Ca');
    [CellofInitialCentroidofCa,VectorofInitialCofCa]=InitializationofCaDistribution(SituationCCaOutSide,BasicSettings);
    InformationInitializedofCa.CellofInitialCentroidofCa=CellofInitialCentroidofCa;
    InformationInitializedofCa.VectorofInitialCofCa=VectorofInitialCofCa;
    %% Define the Iteration Sequence of all the Origion of Ca
    disp('Define the Iteration Sequence of all the Origion of Ca');
    [IterationSequenceCell]=DefineIterationSequence(BasicSettings,InformationInitializedofCa);
    %% Plot the Initializetion Distribution of Ca
    disp('Plot the Initializetion Distribution of Ca');
    [SpaceofCaCell,SearchSpace]=PlotFunctionofCa(InformationInitializedofCa,InformationInitializedofSomas,IterationSequenceCell,SituationCCaDiffusion,BasicSettings);
    %% Display the Statical Data for the Initialized Distribution of Ca
    disp('Display the Statical Data for the Initialized Distribution of Ca');
    [StaticalInformationStructureofCa]=StaticalAnalysisofCaDistribution(SpaceofCaCell,BasicSettings);
    %% Add the Soma Information to the Initializetion Distribution of Ca
    disp('Add the Soma Information to the Initializetion Distribution of Ca');
    [InitializedSpaceofCaCell,TheIndexofSoma,TheMembraneofSoma]=AddSomaInformation(SpaceofCaCell,SituationCCaDiffusion,InformationInitializedofSomas,BasicSettings);
    InitializedInformation.InitializedSpaceofCaCell=InitializedSpaceofCaCell;
    InitializedInformation.TheIndexofSoma=TheIndexofSoma;
    InitializedInformation.TheMembraneofSoma=TheMembraneofSoma;
    elseif InitializationType==2
    %% Define the Initialization Distribution of Somas
    disp('Define the Initialization Distribution of Somas');
    [CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas]=InitializationofSomaDistribution(BasicSettings,SituationSomas);
    InformationInitializedofSomas.CellofInitialCentroidofSomas=CellofInitialCentroidofSomas;
    InformationInitializedofSomas.VectorofInitialRadiusofSomas=VectorofInitialRadiusofSomas;
    %% Plot the Initializetion Distribution of Somas
    disp('Plot the Initializetion Distribution of Somas');
    [XLocationofCentroid,YLocationofCentroid,ZLocationofCentroid,VectorofInitialColorofSomas,FigureofInitialSoma]=PlotFunctionofSomas(InformationInitializedofSomas,SituationSomas);
    InitializetionPlotInformationofSoma.XLocationofCentroid=XLocationofCentroid;
    InitializetionPlotInformationofSoma.YLocationofCentroid=YLocationofCentroid;
    InitializetionPlotInformationofSoma.ZLocationofCentroid=ZLocationofCentroid;
    InitializetionPlotInformationofSoma.VectorofInitialColorofSomas=VectorofInitialColorofSomas;
    %% Define the Second Type of Initialization Distribution of Ca
    [SpaceofCaCell,SearchSpace]=FastTypeInitializationofCa(SituationCCaOutSide,BasicSettings);
    %% Add the Soma Information to the Initializetion Distribution of Ca
    disp('Add the Soma Information to the Initializetion Distribution of Ca');
    [InitializedSpaceofCaCell,TheIndexofSoma,TheMembraneofSoma]=AddSomaInformation(SpaceofCaCell,SituationCCaDiffusion,InformationInitializedofSomas,BasicSettings);
    InitializedInformation.InitializedSpaceofCaCell=InitializedSpaceofCaCell;
    InitializedInformation.TheIndexofSoma=TheIndexofSoma;
    InitializedInformation.TheMembraneofSoma=TheMembraneofSoma;
end

%% Formal Experiment Type
% There are two types of the formal experiments. The first one is
% the complete one, which takes the real-time diffuision of Ca into
% consideration. The second one is the fast type, which doesn't includes
% the diffuision of Ca and use a static Ca distribution. If you want to run
% the real situation but a time-costing experiment, you can use the first
% time. If you can accpet the reasonable noise and want a fast experiment,
% you can use the second one.
FormalExperimentType=2;                                           % Type 1 for the first type and type 2 for the second type

%% Neural Development Experiment
IterationCellofInfluxSpace=cell(ExperimentTimes,5);
IterationCellofNeuralSpace=cell(ExperimentTimes,2);
MulitDPofLamellipodiaCellAccrostheTime=cell(ExperimentTimes,1);
if FormalExperimentType==1
    for IDIteration=1:ExperimentTimes
        %% Define the Iteration Space Relevant with Somas
        disp('Define the Iteration Space Relevant with Somas');
        [IterationSequencefromSomaCell]=DefineIterationSequencefromSoma(BasicSettings,InformationInitializedofSomas);
        %% Deffuision Outside of Soma
        disp('Deffuision Outside of Soma');
        [IterationCellofNeuralSpace]=PlotFunctionofCaOutside(InformationInitializedofCa,InformationInitializedofSomas,IterationSequencefromSomaCell,SituationCCaDiffusion,BasicSettings,IDIteration,IterationCellofNeuralSpace,SearchSpace);
        %% Early Period of Neural Development: Dendritic and Axonal Morphogenesis
        %% The Development of Lamellipodia
        disp('Analyze the Ca Influx Situation of Each Soma');
        [IterationCellofInfluxSpace]=SituationoftheMembraneforSomas(InitializedInformation,SearchSpace,SituationSomas,BasicSettings,IDIteration,IterationCellofInfluxSpace,IterationCellofNeuralSpace);
        InfluxSituationInformation.LocationofMembraneVectorCell=IterationCellofInfluxSpace{IDIteration,1};
        InfluxSituationInformation.SituationofMembraneVectorCell=IterationCellofInfluxSpace{IDIteration,2};
        InfluxSituationInformation.InsidePointofAllSomaCell=IterationCellofInfluxSpace{IDIteration,3};
        InfluxSituationInformation.OutsidePointofAllSomaCell=IterationCellofInfluxSpace{IDIteration,4};
        disp('Add the Influx of Ca to of Each Soma');
        [IterationCellofNeuralSpace]=InfluxFunctionofCa(InfluxSituationInformation,SituationCaInflux,InitializedInformation,SituationSomas,InformationInitializedofSomas,IDIteration,IterationCellofNeuralSpace,IterationTime);
        SituationofInfluxedInformation.InfluexedCaSpace=IterationCellofNeuralSpace{IDIteration,1};
        SituationofInfluxedInformation.AddValueVectorMultiCell=IterationCellofNeuralSpace{IDIteration,2};
        disp('Define the Development probability of Lamellipodia');
        [MulitDPofLamellipodiaCellAccrostheTime]=DefinetheDPofLamellipodia(IterationCellofNeuralSpace,MulitDPofLamellipodiaCellAccrostheTime,IDIteration);
        disp('Start to Growth the Lamellipodia');
        [FigureofNeuron]=GrowthofLamellipodia(IterationCellofInfluxSpace,MulitDPofLamellipodiaCellAccrostheTime,InformationInitializedofSomas,SituationSomas,IDIteration);
        %% Lamellipodia Condensation into Neurites
    end
else
    for IDIteration=1
        %% Early Period of Neural Development: Dendritic and Axonal Morphogenesis
        %% The Development of Lamellipodia
        disp('Analyze the Ca Influx Situation of Each Soma');
        [IterationCellofInfluxSpace]=SituationoftheMembraneforSomas(InitializedInformation,SearchSpace,SituationSomas,BasicSettings,IDIteration,IterationCellofInfluxSpace,IterationCellofNeuralSpace);
        InfluxSituationInformation.LocationofMembraneVectorCell=IterationCellofInfluxSpace{IDIteration,1};
        InfluxSituationInformation.SituationofMembraneVectorCell=IterationCellofInfluxSpace{IDIteration,2};
        InfluxSituationInformation.InsidePointofAllSomaCell=IterationCellofInfluxSpace{IDIteration,3};
        InfluxSituationInformation.OutsidePointofAllSomaCell=IterationCellofInfluxSpace{IDIteration,4};
        disp('Add the Influx of Ca to of Each Soma');
        [IterationCellofNeuralSpace]=InfluxFunctionofCa(InfluxSituationInformation,SituationCCaDiffusion,SituationCaInflux,InitializedInformation,SituationSomas,InformationInitializedofSomas,IDIteration,IterationCellofNeuralSpace,IterationTime);
        SituationofInfluxedInformation.InfluexedCaSpace=IterationCellofNeuralSpace{IDIteration,1};
        SituationofInfluxedInformation.AddValueVectorMultiCell=IterationCellofNeuralSpace{IDIteration,2};
        disp('Define the Development probability of Lamellipodia');
        [MulitDPofLamellipodiaCellAccrostheTime]=DefinetheDPofLamellipodia(IterationCellofNeuralSpace,MulitDPofLamellipodiaCellAccrostheTime,IDIteration);
        disp('Start to Growth the Lamellipodia');
        [FigureofNeuron]=GrowthofLamellipodia(IterationCellofInfluxSpace,MulitDPofLamellipodiaCellAccrostheTime,InformationInitializedofSomas,SituationSomas,IDIteration);
        %% Lamellipodia Condensation into Neurites
    end
end

