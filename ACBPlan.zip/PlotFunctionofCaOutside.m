function [IterationCellofNeuralSpace]=PlotFunctionofCaOutside(InitializedSpaceofCaCell,IterationSequencefromSomaCell,SituationCCaDiffusion,BasicSettings,IDIteration,IterationCellofNeuralSpace,SearchSpace)
%% Load the Information
IterationTime=BasicSettings.IterationTime;

DiffusionCCa=SituationCCaDiffusion.DiffusionCCa;

if  IDIteration==1
    CaSpace=InitializedSpaceofCaCell{end,1};
else
    CaSpace=IterationCellofNeuralSpace{IDIteration-1,1};
end

%% Start to Run the Iteration
      disp(['Space in the Iteration of', num2str(IDIt), '-Starts to Process']);
      IterationCellofNeuralSpace{IDIteration,1}=DiffusionofCaOutside(CaSpace,DiffusionCCa,IterationSequencefromSomaCell,SearchSpace,IterationTime,IDIteration);