function [IterationSequenceCell]=DefineIterationSequence(BasicSettings,InformationInitializedofCa)
Width=BasicSettings.Width;
Length=BasicSettings.Length;
Hight=BasicSettings.Hight;

CellofInitialCentroidofCa=InformationInitializedofCa.CellofInitialCentroidofCa;

IterationSequenceCell=cell(size(CellofInitialCentroidofCa,1),3);
for ID0=1:size(CellofInitialCentroidofCa,1)
      OrigionLocation=CellofInitialCentroidofCa{ID0,1};
      IterationSequence=zeros(Width,Length,Hight,1);
      for ID1=2:(Width-1)
            for ID2=2:(Length-1)
                  for ID3=2:(Hight-1)
                        disp(['Generating the Sequence for ', num2str(ID0), 'at the Location of ', num2str(ID1), '-', num2str(ID2), '-', num2str(ID3)]);
                        if sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)==0
                            IterationSequence(ID1,ID2,ID3,1)=1;
                        elseif (sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)>0)&&((sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)<sqrt(3))||(sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)==sqrt(3)))
                            IterationSequence(ID1,ID2,ID3,1)=2;
                        elseif (sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)>sqrt(3))&&(mod(sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2),sqrt(3))==0)
                             IterationSequence(ID1,ID2,ID3,1)=sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)/sqrt(3)+1;
                        elseif (sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)>sqrt(3))&&(mod(sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2),sqrt(3))~=0)
                             IterationSequence(ID1,ID2,ID3,1)=(sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2)-mod(sqrt((ID1-OrigionLocation(1))^2+(ID2-OrigionLocation(2))^2+(ID3-OrigionLocation(3))^2),sqrt(3)))/sqrt(3)+2;     
                        end
                  end
            end
      end
      IterationSequenceCell{ID0,1}=IterationSequence;
      IterationSequenceCell{ID0,2}=max(max(max(IterationSequence(:,:,:,1))));
      disp(['The Max is', num2str(max(max(max(IterationSequence(:,:,:,1)))))]);
      for IDFind=1:IterationSequenceCell{ID0,2}
            PreLocation=find(floor(IterationSequence(:,:,:,1))==IDFind);
%             CorrespondingLocation{IDFind,1}=[fix((PreLocation-1)/(Width*Length))+1,fix(rem((PreLocation-1),(Width*Length))/Width)+1,rem(rem((PreLocation-1),Width*Length),Width)+1];
            CorrespondingLocation{IDFind,1}=[rem(rem((PreLocation-1),Width*Length),Width)+1, fix(rem((PreLocation-1),(Width*Length))/Width)+1, fix((PreLocation-1)/(Width*Length))+1];
      end
      IterationSequenceCell{ID0,3}=CorrespondingLocation;
end


