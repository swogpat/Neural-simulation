function [CentreValue,EnvelopeValue]=PasstheSubstance(PreSpaceofCa,CentrePoint,TheLocationNeededtoThink,DiffusionCCa,IterationTime)
             ID1=CentrePoint(1);
             ID2=CentrePoint(2);
             ID3=CentrePoint(3);
PreDiffusionValue=zeros(size(TheLocationNeededtoThink,1),1);
EnvelopeValue=zeros(size(TheLocationNeededtoThink,1),1);
for ID=1:size(TheLocationNeededtoThink,1)
    XYZother=TheLocationNeededtoThink(ID,:);
    PreDiffusionValue(ID)=IterationTime*DiffusionCCa*(PreSpaceofCa(XYZother(1),XYZother(2),XYZother(3),1)-PreSpaceofCa(ID1,ID2,ID3,1))*1/size(TheLocationNeededtoThink,1);
    EnvelopeValue(ID)=IterationTime*DiffusionCCa*(-1)*PreDiffusionValue(ID)*1/size(TheLocationNeededtoThink,1);
end
CentreValue=PreSpaceofCa(ID1,ID2,ID3,1)+sum(sum(PreDiffusionValue));

