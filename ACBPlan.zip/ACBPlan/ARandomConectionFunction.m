function []=ARandomConectionFunction(CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas)



