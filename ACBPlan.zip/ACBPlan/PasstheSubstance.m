function [NewValue]=PasstheSubstance(PreSpaceofCa,ID1,ID2,ID3,TheLocationNeededtoThink,DiffusionCCa)
PreDiffusionValue=zeros(size(TheLocationNeededtoThink,1),1);
for ID=1:size(TheLocationNeededtoThink,1)
    XYZother=TheLocationNeededtoThink(ID,:);
    PreDiffusionValue(ID)=PreSpaceofCa(XYZother(1),XYZother(2),XYZother(3),1)-PreSpaceofCa(ID1,ID2,ID3,1);
end
NewValue=PreSpaceofCa(ID1,ID2,ID3,1)+0.01*DiffusionCCa*sum(sum(PreDiffusionValue));

