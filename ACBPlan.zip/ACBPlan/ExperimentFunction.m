%% Initialization Part
%% Initial Settings
Width=500000;
Length=500000;
Hight=500000;
MinRadius=50;
MaxRadius=350;
NumofInitialSomas=1000;
%% Define the Initialization Distribution of Somas
[CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas]=InitializationofSomaDistribution(Width,Length,Hight,NumofInitialSomas,MinRadius,MaxRadius);
%% Plot the Initializetion Distribution of Somas
[XLocationofCentroid,YLocationofCentroid,ZLocationofCentroid,VectorofInitialColorofSomas,FigureofInitialSoma]=PlotFunctionofSomas(CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas,MinRadius,MaxRadius);
%% Define the Initialization Distribution of 
