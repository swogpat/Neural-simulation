%% Initialization Part
%% Initial Settings
% In this part, we define some basic information for our computtational
% model. The [Width,Length,Hight] will define the whole space, and the norm
% is 1 micrometer. The IterationTime=0.01 means that each iteration
% corresponds to 0.01 s or 10 ms. Apart of that, the norm of all
% concentration is umol/um^3.

Width=50;
Length=50;
Hight=50;
InitialIterationTimes=200;
MinRadius=2.5;
MaxRadius=175;
NumofInitialSomas=3;
NumofInitialCa=10;
MinCCaOutSide=Width*Length*Hight/NumofInitialCa*1000*10^(-15);
MaxCCaOutSide=Width*Length*Hight/NumofInitialCa*2000*10^(-15);
MinCCaInSide=0.1*10^(-15);
MaxCCaInSide=1*10^(-15);
IterationTime=0.01;
DiffusionCCa=1;

%% Define the Structure of Settings
% In this part, we define some structure to pass the information.
BasicSettings.Width=Width;
BasicSettings.Length=Length;
BasicSettings.Hight=Hight;
BasicSettings.IterationTime=IterationTime;
BasicSettings.InitialIterationTimes=InitialIterationTimes;

SituationCCaOutSide.NumofInitialCa=NumofInitialCa;
SituationCCaOutSide.MinCCaOutSide=MinCCaOutSide;
SituationCCaOutSide.MaxCCaOutSide=MaxCCaOutSide;

SituationSomas.NumofInitialSomas=NumofInitialSomas;
SituationSomas.MinRadius=MinRadius;
SituationSomas.MaxRadius=MaxRadius;

SituationCCaDiffusion.DiffusionCCa=DiffusionCCa;
SituationCCaDiffusion.MinCCaInSide=MinCCaInSide;
SituationCCaDiffusion.MaxCCaInSide=MaxCCaInSide;

%% Define the Iteration Sequence of the Whole Space
disp('Define the Iteration Sequence of the Whole Space');
[IterationSequence]=DefineIterationSequence(BasicSettings);
%% Define the Initialization Distribution of Somas
disp('Define the Initialization Distribution of Somas');
[CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas]=InitializationofSomaDistribution(BasicSettings,SituationSomas);
InformationInitializedofSomas.CellofInitialCentroidofSomas=CellofInitialCentroidofSomas;
InformationInitializedofSomas.VectorofInitialRadiusofSomas=VectorofInitialRadiusofSomas;
%% Plot the Initializetion Distribution of Somas
disp('Plot the Initializetion Distribution of Somas');
[XLocationofCentroid,YLocationofCentroid,ZLocationofCentroid,VectorofInitialColorofSomas,FigureofInitialSoma]=PlotFunctionofSomas(InformationInitializedofSomas,SituationSomas);
%% Define the Initialization Distribution of Ca
disp('Define the Initialization Distribution of Ca');
[CellofInitialCentroidofCa,VectorofInitialCofCa]=InitializationofCaDistribution(SituationCCaOutSide,BasicSettings);
InformationInitializedofCa.CellofInitialCentroidofCa=CellofInitialCentroidofCa;
InformationInitializedofCa.VectorofInitialCofCa=VectorofInitialCofCa;
%% Plot the Initializetion Distribution of Ca
disp('Plot the Initializetion Distribution of Ca');
[SpaceofCaCell,SearchSpace,InitializedSpaceofCa]=PlotFunctionofCa(InformationInitializedofCa,InformationInitializedofSomas,IterationSequence,SituationCCaDiffusion,BasicSettings);
