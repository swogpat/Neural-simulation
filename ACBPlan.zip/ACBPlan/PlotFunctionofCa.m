function [SpaceofCaCell,SearchSpace,InitializedSpaceofCa]=PlotFunctionofCa(InformationInitializedofCa,InformationInitializedofSomas,IterationSequence,SituationCCaDiffusion,BasicSettings)

Width=BasicSettings.Width;
Length=BasicSettings.Length;
Hight=BasicSettings.Hight;
InitialIterationTimes=BasicSettings.InitialIterationTimes;

DiffusionCCa=SituationCCaDiffusion.DiffusionCCa;
MinCCaInSide=SituationCCaDiffusion.MinCCaInSide;
MaxCCaInSide=SituationCCaDiffusion.MaxCCaInSide;

CellofInitialCentroidofCa=InformationInitializedofCa.CellofInitialCentroidofCa;
VectorofInitialCofCa=InformationInitializedofCa.VectorofInitialCofCa;

CellofInitialCentroidofSomas=InformationInitializedofSomas.CellofInitialCentroidofSomas;
VectorofInitialRadiusofSomas=InformationInitializedofSomas.VectorofInitialRadiusofSomas;

SpaceofCa=zeros(Width,Length,Hight,1);
for ID=1:size(CellofInitialCentroidofCa,1)
     XYZCa=CellofInitialCentroidofCa{ID,1};
     SpaceofCa(XYZCa(1),XYZCa(2),XYZCa(3),1)=VectorofInitialCofCa(ID);
     for ID1=1:size(CellofInitialCentroidofSomas)
           XYZS=CellofInitialCentroidofSomas{ID1,1};
           if (sqrt((XYZCa(1)-XYZS(1))^2+(XYZCa(2)-XYZS(2))^2+(XYZCa(3)-XYZS(3))^2)<VectorofInitialRadiusofSomas(ID1))||(sqrt((XYZCa(1)-XYZS(1))^2+(XYZCa(2)-XYZS(2))^2+(XYZCa(3)-XYZS(3))^2)==VectorofInitialRadiusofSomas(ID1))
               SpaceofCa(XYZCa(1),XYZCa(1),XYZCa(1),1)=0;
           end
    end
end

Dir1=[-1,0,1];
Dir2=[-1,0,1];
Dir3=[-1,0,1];
[Search1,Search2,Search3] = meshgrid(Dir1,Dir2,Dir3);
SearchSpace=[Search1(:), Search2(:), Search3(:)]; 

SpaceofCaCell=cell(InitialIterationTimes,1);
SpaceofCaCell{1,1}=SpaceofCa;
for ID=1:(InitialIterationTimes-1)
      tic;
      disp([num2str(ID), '-Start to Process']);
      SpaceofCaCell{ID+1,1}=DiffusionofCa(SpaceofCaCell{ID,1},DiffusionCCa,IterationSequence,SearchSpace);
      toc;
end

InitializedSpaceofCa=SpaceofCaCell{end,1};
for ID1=1:Width
    for ID2=1:Length
        for ID3=1:Hight
             for ID4=1:size(CellofInitialCentroidofSomas)
                     XYZS=CellofInitialCentroidofSomas{ID4,1};
                    if (sqrt((ID1-XYZS(1))^2+(ID2-XYZS(2))^2+(ID3-XYZS(3))^2)<VectorofInitialRadiusofSomas(ID1))||(sqrt((ID1-XYZS(1))^2+(ID2-XYZS(2))^2+(ID3-XYZS(3))^2)==VectorofInitialRadiusofSomas(ID1))
                     SpaceofCa(ID1,ID2,ID3,1)=MinCCaInSide + (MaxCCaInSide-MinCCaInSide).*rand(1,1);
                    end
             end
        end
    end
end

















