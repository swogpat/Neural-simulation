function [NewSpaceofCa]=DiffusionofCa(PreSpaceofCa,DiffusionCCa,IterationSequence,SearchSpace)
TheEnvelope=zeros(size(SearchSpace,1),3);
TheOrderInEnvelope=zeros(size(SearchSpace,1),1);
NewSpaceofCa=PreSpaceofCa;
for ID1=2:(size(PreSpaceofCa,1)-1)
    for ID2=2:(size(PreSpaceofCa,2)-1)
        for ID3=2:(size(PreSpaceofCa,3)-1)
            disp([num2str(ID1), '-', num2str(ID2), '-', num2str(ID3), '- Is under Processing Now']);
             for IDSearch=1:size(SearchSpace,1)
                   XYZSearched=SearchSpace(IDSearch,:)+[ID1,ID2,ID3];
                   TheEnvelope(IDSearch,:)=XYZSearched;
                   TheOrderInEnvelope(IDSearch,1)=IterationSequence(XYZSearched(1),XYZSearched(2),XYZSearched(3),1);
             end
             TheIndexNeededtoThink=find(TheOrderInEnvelope(:)>IterationSequence(ID1,ID2,ID3,1));
             TheLocationNeededtoThink=zeros(length(TheIndexNeededtoThink),3);
             for IDIndex=1:length(TheIndexNeededtoThink)
             TheLocationNeededtoThink(IDIndex,:)=TheEnvelope(TheIndexNeededtoThink(IDIndex),:);
             end
             NewSpaceofCa(ID1,ID2,ID3,1)=PasstheSubstance(PreSpaceofCa,ID1,ID2,ID3,TheLocationNeededtoThink,DiffusionCCa);
        end
    end
end