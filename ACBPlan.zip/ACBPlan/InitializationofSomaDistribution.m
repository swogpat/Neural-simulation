function [CellofInitialCentroidofSomas,VectorofInitialRadiusofSomas]=InitializationofSomaDistribution(Width,Length,Hight,NumofInitialSomas,MinRadius,MaxRadius)
%% Generation of the Whole Space
Limitation=[Width,Length,Hight];

%% Generation of the Somas
CellofInitialCentroidofSomas=cell(NumofInitialSomas,1);
VectorofInitialRadiusofSomas=zeros(NumofInitialSomas,1);
for ID=1:NumofInitialSomas
InitialCentroidofSomas=[randi([1 Limitation(1,1)],1,1),randi([1 Limitation(1,2)],1,1),randi([1 Limitation(1,3)],1,1)];
CellofInitialCentroidofSomas{ID,1}=InitialCentroidofSomas;
%VectorofInitialRadiusofSomas(ID,1)=randi([MinRadius,MaxRadius],1,1);
VectorofInitialRadiusofSomas(ID,1)=MinRadius + (MaxRadius-MinRadius).*rand(1,1);
end