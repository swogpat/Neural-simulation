function [IterationSequence]=DefineIterationSequence(BasicSettings)
Width=BasicSettings.Width;
Length=BasicSettings.Length;
Hight=BasicSettings.Hight;
IterationSequence=zeros(Width,Length,Hight,1);
for ID1=1:Width
    for ID2=1:Length
          for ID3=1:Hight
               disp([num2str(ID1), '-', num2str(ID2), '-', num2str(ID3)]);
                if (sqrt(ID1^2+ID2^2+ID3^2)<sqrt(3))||(sqrt(ID1^2+ID2^2+ID3^2)==sqrt(3))
                    IterationSequence(ID1,ID2,ID3,1)=1;
                elseif (sqrt(ID1^2+ID2^2+ID3^2)>sqrt(3))&&(mod(sqrt(ID1^2+ID2^2+ID3^2),sqrt(3))==0)
                     IterationSequence(ID1,ID2,ID3,1)=sqrt(ID1^2+ID2^2+ID3^2)/sqrt(3);
                elseif (sqrt(ID1^2+ID2^2+ID3^2)>sqrt(3))&&(mod(sqrt(ID1^2+ID2^2+ID3^2),sqrt(3))~=0)
                     IterationSequence(ID1,ID2,ID3,1)=(sqrt(ID1^2+ID2^2+ID3^2)-mod(sqrt(ID1^2+ID2^2+ID3^2),sqrt(3)))/sqrt(3)+1;     
                end
          end
    end
end