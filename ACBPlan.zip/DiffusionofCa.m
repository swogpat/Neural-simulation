function [NewSpaceofCa]=DiffusionofCa(PreSpaceofCa,DiffusionCCa,IterationSequenceCell,SearchSpace,IterationTime,IDIt)

%% Define the Envelope and other Matrix
TheEnvelope=zeros(size(SearchSpace,1),3);
TheOrderInEnvelope=zeros(size(SearchSpace,1),1);
NewSpaceofCa=PreSpaceofCa;

%% Start to Work out the Diffusion 
for ID1=1:size(IterationSequenceCell,1)
IterationSequenceLocationNeeded=IterationSequenceCell{ID1,3};
IterationSequence=IterationSequenceCell{ID1,1};
ModInfo=floor(IterationSequenceCell{ID1,2});
    for IDPre=1:IDIt
          if (IDPre<ModInfo)||(IDPre==ModInfo)
              ID2=floor(IDPre);
          elseif (IDPre>ModInfo)&&(mod(IDPre,ModInfo)==0)
              ID2=floor(ModInfo);
          elseif (IDPre>ModInfo)&&(mod(IDPre,ModInfo)~=0)
              ID2=floor(mod(IDPre,ModInfo));  
          end
          disp(ID2);
          LocationMatrix=IterationSequenceLocationNeeded{ID2,1};
          for ID3=1:size(LocationMatrix,1)
                CentrePoint=LocationMatrix(ID3,:);
                for IDSearch=1:size(SearchSpace,1)
                    XYZSearched=SearchSpace(IDSearch,:)+CentrePoint;
                    TheEnvelope(IDSearch,:)=XYZSearched;
                     TheOrderInEnvelope(IDSearch,1)=IterationSequence(XYZSearched(1),XYZSearched(2),XYZSearched(3),1);
                end
                 TheIndexNeededtoThink=find((TheOrderInEnvelope(:)>IterationSequence(CentrePoint(1),CentrePoint(2),CentrePoint(3),1))|(TheOrderInEnvelope(:)==IterationSequence(CentrePoint(1),CentrePoint(2),CentrePoint(3),1)));
                 TheLocationNeededtoThink=zeros(length(TheIndexNeededtoThink),3);
                 for IDIndex=1:length(TheIndexNeededtoThink)
                       TheLocationNeededtoThink(IDIndex,:)=TheEnvelope(TheIndexNeededtoThink(IDIndex),:);
                 end
                [CentreValue,EnvelopeValue]=PasstheSubstance(PreSpaceofCa,CentrePoint,TheLocationNeededtoThink,DiffusionCCa,IterationTime);
                NewSpaceofCa(CentrePoint(1),CentrePoint(2),CentrePoint(3),1)=CentreValue;
                for ID4=1:size(TheLocationNeededtoThink,1)
                      XYZother=TheLocationNeededtoThink(ID4,:);
                      NewSpaceofCa(XYZother(1),XYZother(2),XYZother(3),1)=NewSpaceofCa(XYZother(1),XYZother(2),XYZother(3),1)+EnvelopeValue(ID4);
                end
          end
    end
end

