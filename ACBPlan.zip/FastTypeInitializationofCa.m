function [SpaceofCaCell,SearchSpace]=FastTypeInitializationofCa(SituationCCaOutSide,BasicSettings)
%% Load the Information
Width=BasicSettings.Width;
Length=BasicSettings.Length;
Hight=BasicSettings.Hight;

MinCCaOutSideFast=SituationCCaOutSide.MinCCaOutSideFast;
MaxCCaOutSideFast=SituationCCaOutSide.MaxCCaOutSideFast;

%% Define the Search Space
Dir1=[-1,0,1];
Dir2=[-1,0,1];
Dir3=[-1,0,1];
[Search1,Search2,Search3] = meshgrid(Dir1,Dir2,Dir3);
SearchSpace=[Search1(:), Search2(:), Search3(:)]; 

%% Define the Distribution
SpaceofCa=zeros(Width,Length,Hight,1);
for ID1=1:Width
    for ID2=1:Length
        for ID3=1:Hight
              SpaceofCa(ID1,ID2,ID3,1)=MinCCaOutSideFast + (MaxCCaOutSideFast-MinCCaOutSideFast).*rand(1,1);
        end
    end
end
SpaceofCaCell{1,1}=SpaceofCa;


